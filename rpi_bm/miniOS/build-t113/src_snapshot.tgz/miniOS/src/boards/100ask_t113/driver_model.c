#include "platform.h"
#include "driver_model.h"
#include "device.h"

static struct kobject kernel_root;
static struct kset devices;
static struct kset drivers;
static struct kset buses;
static struct bus_type platform_bus = { .name = "platform" };
static struct device uart3_device = { .name = "uart3" };
static struct device gic_device = { .name = "gic" };
static struct device timer0_device = { .name = "timer0" };

static const struct kobj_type static_ktype = {
    .release = 0,
};

void t113_driver_core_init(void)
{
    kobject_init(&kernel_root, &static_ktype);
    kobject_add(&kernel_root, 0, 0, "kernel");

    kset_init(&devices, &static_ktype);
    kset_init(&drivers, &static_ktype);
    kset_init(&buses, &static_ktype);
    kset_register(&devices, &kernel_root, "devices");
    kset_register(&drivers, &kernel_root, "drivers");
    kset_register(&buses, &kernel_root, "bus");
    bus_register(&platform_bus);
    uart3_device.bus = &platform_bus;
    gic_device.bus = &platform_bus;
    timer0_device.bus = &platform_bus;
    device_register(&uart3_device);
    device_register(&gic_device);
    device_register(&timer0_device);
    t113_uart_puts("driver core: /bus/platform/{devices,drivers} ready\n");
}

struct kset *t113_devices_kset(void) { return &devices; }
struct kset *t113_drivers_kset(void) { return &drivers; }
struct kset *t113_buses_kset(void) { return &buses; }
