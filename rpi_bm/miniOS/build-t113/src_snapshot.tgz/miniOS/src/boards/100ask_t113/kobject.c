#include "kobject.h"

static int string_equal(const char *a, const char *b)
{
    if (!a || !b)
        return 0;
    while (*a && *a == *b) {
        ++a;
        ++b;
    }
    return *a == *b;
}

void kobject_init(struct kobject *kobj, const struct kobj_type *ktype)
{
    kobj->name = 0;
    kobj->parent = 0;
    kobj->kset = 0;
    kobj->ktype = ktype;
    kobj->ref.refs = 1;
    spin_lock_init(&kobj->ref.lock);
    INIT_LIST_HEAD(&kobj->entry);
    kobj->state_in_kset = 0;
}

struct kobject *kobject_get(struct kobject *kobj)
{
    if (!kobj)
        return 0;
    uint32_t flags = spin_lock_irqsave(&kobj->ref.lock);
    if (!kobj->ref.refs) {
        spin_unlock_irqrestore(&kobj->ref.lock, flags);
        return 0;
    }
    ++kobj->ref.refs;
    spin_unlock_irqrestore(&kobj->ref.lock, flags);
    return kobj;
}

void kobject_del(struct kobject *kobj)
{
    if (!kobj || !kobj->state_in_kset)
        return;
    struct kset *kset = kobj->kset;
    uint32_t flags = spin_lock_irqsave(&kset->lock);
    if (kobj->state_in_kset) {
        list_del_init(&kobj->entry);
        kobj->state_in_kset = 0;
    }
    spin_unlock_irqrestore(&kset->lock, flags);
}

void kobject_put(struct kobject *kobj)
{
    if (!kobj)
        return;
    uint32_t flags = spin_lock_irqsave(&kobj->ref.lock);
    if (!kobj->ref.refs) {
        spin_unlock_irqrestore(&kobj->ref.lock, flags);
        return;
    }
    int release = --kobj->ref.refs == 0;
    spin_unlock_irqrestore(&kobj->ref.lock, flags);
    if (!release)
        return;

    kobject_del(kobj);
    struct kobject *parent = kobj->parent;
    kobj->parent = 0;
    if (kobj->ktype && kobj->ktype->release)
        kobj->ktype->release(kobj);
    kobject_put(parent);
}

int kobject_add(struct kobject *kobj, struct kset *kset,
                struct kobject *parent, const char *name)
{
    if (!kobj || !name || kobj->state_in_kset)
        return -1;
    kobj->name = name;
    kobj->parent = kobject_get(parent);
    kobj->kset = kset;
    if (kset) {
        uint32_t flags = spin_lock_irqsave(&kset->lock);
        struct list_head *node;
        for (node = kset->members.next; node != &kset->members;
             node = node->next) {
            struct kobject *member = list_entry(node, struct kobject, entry);
            if (string_equal(member->name, name)) {
                spin_unlock_irqrestore(&kset->lock, flags);
                kobject_put(kobj->parent);
                kobj->parent = 0;
                kobj->kset = 0;
                return -1;
            }
        }
        list_add_tail(&kobj->entry, &kset->members);
        kobj->state_in_kset = 1;
        spin_unlock_irqrestore(&kset->lock, flags);
    }
    return 0;
}

void kset_init(struct kset *kset, const struct kobj_type *ktype)
{
    kobject_init(&kset->kobj, ktype);
    INIT_LIST_HEAD(&kset->members);
    spin_lock_init(&kset->lock);
}

int kset_register(struct kset *kset, struct kobject *parent,
                  const char *name)
{
    return kobject_add(&kset->kobj, 0, parent, name);
}

void kset_unregister(struct kset *kset)
{
    if (kset)
        kobject_put(&kset->kobj);
}

struct kobject *kset_find_obj(struct kset *kset, const char *name)
{
    if (!kset || !name)
        return 0;
    uint32_t flags = spin_lock_irqsave(&kset->lock);
    struct list_head *node;
    struct kobject *found = 0;
    for (node = kset->members.next; node != &kset->members;
         node = node->next) {
        struct kobject *member = list_entry(node, struct kobject, entry);
        if (string_equal(member->name, name)) {
            found = kobject_get(member);
            break;
        }
    }
    spin_unlock_irqrestore(&kset->lock, flags);
    return found;
}
