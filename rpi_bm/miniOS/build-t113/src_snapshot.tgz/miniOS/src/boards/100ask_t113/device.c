#include "device.h"
#include "driver_model.h"

static const struct kobj_type bus_ktype = { .release = 0 };
static const struct kobj_type device_ktype = { .release = 0 };
static const struct kobj_type driver_ktype = { .release = 0 };

static int names_match(const char *a, const char *b)
{
    if (!a || !b)
        return 0;
    while (*a && *a == *b) {
        ++a;
        ++b;
    }
    return *a == *b;
}

static int match(struct bus_type *bus, struct device *dev,
                 struct device_driver *drv)
{
    return bus->match ? bus->match(dev, drv)
                      : names_match(dev->name, drv->name);
}

static int bind(struct device *dev, struct device_driver *drv)
{
    if (dev->driver || !match(dev->bus, dev, drv))
        return 0;
    if (drv->probe && drv->probe(dev) < 0)
        return -1;
    dev->driver = drv;
    return 1;
}

int bus_register(struct bus_type *bus)
{
    if (!bus || !bus->name)
        return -1;
    kobject_init(&bus->kobj, &bus_ktype);
    if (kobject_add(&bus->kobj, t113_buses_kset(),
                    &t113_buses_kset()->kobj, bus->name) < 0)
        return -1;
    kset_init(&bus->devices, &device_ktype);
    kset_init(&bus->drivers, &driver_ktype);
    if (kset_register(&bus->devices, &bus->kobj, "devices") < 0 ||
        kset_register(&bus->drivers, &bus->kobj, "drivers") < 0) {
        kobject_put(&bus->kobj);
        return -1;
    }
    return 0;
}

void bus_unregister(struct bus_type *bus)
{
    if (!bus)
        return;
    kset_unregister(&bus->drivers);
    kset_unregister(&bus->devices);
    kobject_put(&bus->kobj);
}

int device_register(struct device *dev)
{
    if (!dev || !dev->name || !dev->bus)
        return -1;
    kobject_init(&dev->kobj, &device_ktype);
    if (kobject_add(&dev->kobj, &dev->bus->devices,
                    &dev->bus->kobj, dev->name) < 0)
        return -1;

    struct list_head *node;
    uint32_t flags = spin_lock_irqsave(&dev->bus->drivers.lock);
    for (node = dev->bus->drivers.members.next;
         node != &dev->bus->drivers.members; node = node->next) {
        struct device_driver *drv = container_of(
            list_entry(node, struct kobject, entry),
            struct device_driver, kobj);
        if (bind(dev, drv) > 0)
            break;
    }
    spin_unlock_irqrestore(&dev->bus->drivers.lock, flags);
    return 0;
}

void device_unregister(struct device *dev)
{
    if (!dev)
        return;
    if (dev->driver && dev->driver->remove)
        dev->driver->remove(dev);
    dev->driver = 0;
    kobject_put(&dev->kobj);
}

int driver_register(struct device_driver *drv)
{
    if (!drv || !drv->name || !drv->bus)
        return -1;
    kobject_init(&drv->kobj, &driver_ktype);
    if (kobject_add(&drv->kobj, &drv->bus->drivers,
                    &drv->bus->kobj, drv->name) < 0)
        return -1;

    struct list_head *node;
    uint32_t flags = spin_lock_irqsave(&drv->bus->devices.lock);
    for (node = drv->bus->devices.members.next;
         node != &drv->bus->devices.members; node = node->next) {
        struct device *dev = container_of(
            list_entry(node, struct kobject, entry), struct device, kobj);
        bind(dev, drv);
    }
    spin_unlock_irqrestore(&drv->bus->devices.lock, flags);
    return 0;
}

void driver_unregister(struct device_driver *drv)
{
    if (!drv)
        return;
    struct list_head *node;
    uint32_t flags = spin_lock_irqsave(&drv->bus->devices.lock);
    for (node = drv->bus->devices.members.next;
         node != &drv->bus->devices.members; node = node->next) {
        struct device *dev = container_of(
            list_entry(node, struct kobject, entry), struct device, kobj);
        if (dev->driver != drv)
            continue;
        if (drv->remove)
            drv->remove(dev);
        dev->driver = 0;
    }
    spin_unlock_irqrestore(&drv->bus->devices.lock, flags);
    kobject_put(&drv->kobj);
}

void dev_set_drvdata(struct device *dev, void *data)
{
    if (dev)
        dev->driver_data = data;
}

void *dev_get_drvdata(const struct device *dev)
{
    return dev ? dev->driver_data : 0;
}
