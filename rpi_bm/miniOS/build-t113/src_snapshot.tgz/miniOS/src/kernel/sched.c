#include "sched.h"
#include "irq.h"
#include "printf.h"
#include "fork.h"

static struct task_struct init_task = INIT_TASK;
struct task_struct *current = &(init_task);
struct task_struct * task[NR_TASKS] = {&(init_task), };
int nr_tasks = 1;

void do_exit(int error_code);

void preempt_disable(void)
{
	current->preempt_count++;
}

void preempt_enable(void)
{
	current->preempt_count--;
}


void _schedule(void)
{
	printf("enter _schedule\n\r");
	preempt_disable();
	int next,c;
	struct task_struct * p;
	
	while (1) {
		c = -1;
		next = 0;
		for (int i = 0; i < NR_TASKS; i++){
			p = task[i];
			if (p && p->state == TASK_RUNNING && p->counter > c) {
				if (i != 0)
					printf("task[%d]: state=%d, counter=%d\n\r",
					       i, p->state, p->counter);
			//	c = p->counter;
			//	next = i;
			int eff = p->counter;
            if (eff > c) {
                c = eff;
                next = i;
            }
			}
		}
		if (c) {
			break;
		}
		for (int i = 0; i < NR_TASKS; i++) {
			p = task[i];
			
			if (p) {
				
			if (i != 0) {
				printf("task[%d]: state=%d, counter=%d\n\r",
				       i, p->state, p->counter);
			}
				p->counter = (p->counter >> 1) + p->priority;
			}
		}
	}
	unsigned long next_pgd = task[next]->mm ? task[next]->mm->pgd : 0;
	printf("Switching to task %d at %x with SP=%x,pgd=%x\r\n",
           next, task[next], task[next]->stack, next_pgd);
	//printf("return from _schedule. next=%x,task=%x,\r\n",next,task[next]);
	
	/* Call chain ②: save prev x19-x30/SP and restore next x19-x30/SP.
	 * A new task's restored return address is ret_from_fork. */
	switch_to(task[next]);
	preempt_enable();
}

void schedule(void)
{
	current->counter = 0;
	_schedule();
}

void switch_to(struct task_struct * next) 
{
	if (current == next) 
		return;
	struct task_struct * prev = current;
	current = next;
	if (next->mm && next->mm->pgd)
		switch_user_pgd(next->mm->pgd);

	/* Assembly context switch; its final ret follows next->cpu_context.pc. */
	cpu_switch_to(prev, next);
}

void schedule_tail(void) {
	preempt_enable();
}


void timer_tick()
{
	--current->counter;
	if (current->counter>0 || current->preempt_count >0) {
		return;
	}
	current->counter=0;
	irq_enable();
	_schedule();
	irq_disable();
}


void __ret_from_kernel_thread(void) {
    int (*fn)(void *) = (void *)current->cpu_context.x19;
    void *arg = (void *)current->cpu_context.x20;
    
    int ret = fn(arg);
    do_exit(ret);
}
void do_exit(int error_code) {
    struct task_struct *tsk = current;
    
    // Mark task as zombie
    tsk->state = TASK_ZOMBIE;
    
    // Free resources
    if (tsk->stack && !(tsk->flags & PF_KTHREAD)) {
      //  free_pages(tsk->stack, 1);
    }
    
    // Schedule other tasks
    schedule();
    
    // Should never reach here
    //panic("Zombie task scheduled!\n");
}

void exit_process(){
	preempt_disable();
	for (int i = 0; i < NR_TASKS; i++){
		if (task[i] == current) {
			task[i]->state = TASK_ZOMBIE;

			// 释放用户内存
       //     if (task[i]->mm) {
//                free_user_memory(task[i]->mm);
       //         task[i]->mm = 0;
       //     }

			break;
		}
	}
	if (current->stack) {
		free_page(current->stack);
		current->stack = 0;
	}
	preempt_enable();
	schedule();
}
