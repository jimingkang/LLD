#include "common.h"
#include "mini_uart.h"
#include "printf.h"
#include "irq.h"
#include "timer.h"
#include "i2c.h"
#include "spi.h"
#include "led_display.h"
#include "mailbox.h"
#include "video.h"
#include <io.h>
#include "peripherals/emmc.h"
#include "fork.h"
#include "sched.h"
#include "user.h"
#include "utils.h"
#define PF_KTHREAD		            	0x00000002
#define PF_UTHREAD		            	0x00000000
#define MAX_DEVS 10
io_device *devices[MAX_DEVS] = {0};
void thread_entry(void* arg) {
    printf("Thread running with arg: %p\n", arg);
    while(1);
}

void putc(void *p, char c) {
    if (c == '\n') {
        uart_send('\r');
    }

    uart_send(c);
}

#define BOOT_SIGNATURE 0xAA55

typedef struct PACKED {
    u8 head;
    u8 sector : 6;
    u8 cylinder_hi : 2;
    u8 cylinder_lo;
} chs_address ;

typedef struct PACKED {
    u8 status;
    chs_address first_sector;
    u8 type;
    chs_address last_sector;
    u32 first_lba_sector;
    u32 num_sectors;
} partition_entry ;

typedef struct PACKED {
    u8 bootCode[0x1BE];
    partition_entry partitions[4];
    u16 bootSignature;
} master_boot_record;


void kernel_func(void *arg) {
    printf("kernel_func\r\n");
    int i=0;
    while (1) {

         printf("kernel_func !\r\n");
         delay(1000000);
    }
}

void init_main(void *arg) {
    printf("init_main\r\n");
    int i=0;
    while (1) {

         printf("init_main i=%d!\r\n",i);
         delay(1000000);
    }
}
void kernel_process(void);

static int current_pid(void)
{
    for (int i = 0; i < nr_tasks; i++)
        if (task[i] == current)
            return i;
    return -1;
}

static int kernel_page_table_dumped;

static void dump_process_layout(const char *name, unsigned long image_start)
{
    struct pt_regs *tf = task_pt_regs(current);
    int pid = current_pid();

    printf("\n===== %s process layout (pid=%d) =====\n", name, pid);
    printf("task_struct       : 0x%x\n", current);
    printf("cpu_context       : 0x%x (pc=0x%x sp=0x%x x19=0x%x x20=0x%x)\n",
           &current->cpu_context, current->cpu_context.pc,
           current->cpu_context.sp, current->cpu_context.x19,
           current->cpu_context.x20);
    printf("kernel stack      : [0x%x, 0x%x)\n",
           current->stack, current->stack + THREAD_SIZE);
    printf("trapframe/pt_regs : 0x%x (pc=0x%x sp_el0=0x%x pstate=0x%x)\n",
           tf, tf->pc, tf->sp, tf->pstate);
    printf("user stack        : [0x%x, 0x%x), initial SP=0x%x\n",
           tf->sp - PAGE_SIZE, tf->sp, tf->sp);
    printf("user pgd          : PA=0x%x KVA=0x%x\n",
           current->mm->pgd, __va(current->mm->pgd));

#if MMU_DUMP
    if (!kernel_page_table_dumped) {
        printf("-- kernel TTBR1 mapping (printed once) --\n");
        /* kernel_pgd_addr() is evaluated after entering the high-half kernel,
         * so it returns the KVA of pg_dir.  The walker accepts a physical
         * root and prints every used level down to the leaf/block entry. */
        dump_pagetable_walk(__pa(kernel_pgd_addr()),
                            (unsigned long)&kernel_process);
        kernel_page_table_dumped = 1;
    }
#endif
    (void)kernel_page_table_dumped;
#if MMU_DUMP
    printf("-- user image L0 -> L1 -> L2 -> L3 --\n");
    dump_pagetable_walk(current->mm->pgd, image_start);
    printf("-- user stack L0 -> L1 -> L2 -> L3 --\n");
    dump_pagetable_walk(current->mm->pgd, tf->sp - PAGE_SIZE);
#else
    (void)image_start;
#endif
    printf("===========================================\n\n");
}

static void launch_user_image(const char *name, unsigned long image_start,
                              unsigned long image_end,
                              unsigned long entry)
{
    current->mm = (struct mm_struct *)allocate_kernel_page();
    if (!current->mm) {
        printf("%s: failed to allocate mm_struct\n", name);
        return;
    }
    memzero((u64)current->mm, sizeof(*current->mm));

    current->mm->pgd = allocate_pagetable_page();
    if (!current->mm->pgd) {
        printf("%s: failed to allocate PGD\n", name);
        return;
    }

    int err = move_to_user_mode(image_start, image_end - image_start, entry);
    if (err < 0) {
        printf("%s: failed to move to user mode\n", name);
        return;
    }
    dump_process_layout(name, image_start);
}

void kernel_process2(void)
{
    launch_user_image("user-image-2", (unsigned long)user2_begin,
                      (unsigned long)user2_end,
                      (unsigned long)user_process2);
}

int prepare_move_to_user(u64 start_addr, u64 size, u64 fn)
{
    struct pt_regs *regs = task_pt_regs(current);
    memzero((u64)regs, sizeof(*regs));
    /* jump to fn as EL0 after eret in kernel_exit */
    regs->pc = fn;
    regs->pstate = 0;
    regs->sp = USER_SP_INIT_POS;
    u64 code_page = allocate_user_page(current, 0,USER_FLAGS_CODE);
    if (code_page == 0)
        return -1;
    _memcpy((u64*)code_page, (u64*)start_addr, size);
    set_pgd(current->mm->pgd, regs);
    return 0;
}

struct ke_regs * task_ke_regs(struct task_struct *tsk)
{
    u64 p = (u64)tsk + THREAD_SIZE - sizeof(struct ke_regs);
    return (struct ke_regs *)p;
}
void kernel_process(void){
	printf("\r\nKernel process started. EL %d\r\n", get_el());
    /* Call chain ③: ret_from_fork -> kernel_process -> launch_user_image
     * -> move_to_user_mode.  It builds the user mappings, fills pt_regs and
     * installs this process's page-table root in TTBR0_EL1. */
    launch_user_image("user-image-1", (unsigned long)user_begin,
                      (unsigned long)user_end,
                      (unsigned long)user_main);
}
    /*
void kernel_process(){
	printf("Kernel process started. EL %d\r\n", get_el());
	unsigned long begin = (unsigned long)&user_begin;
	unsigned long end = (unsigned long)&user_end;
	unsigned long process = (unsigned long)&user_process;
	int err = move_to_user_mode(begin, end - begin, process - begin);
	if (err < 0){
		printf("Error while moving process to user mode\n\r");
	} 
}
*/

void kernel_main() {


    uart_init();
    init_printf(0, io_device_find("muart"));
    printf("\nRasperry PI Bare Metal OS Initializing...\n");

    irq_init_vectors();
    enable_interrupt_controller();
    irq_enable();
    timer_init();

#if RPI_VERSION == 3
    printf("\tBoard: Raspberry PI 3\n");
#endif

#if RPI_VERSION == 4
    printf("\tBoard: Raspberry PI 4\n");
#endif

#if INIT_MMU == 1
    printf("Initialized MMU\n");
#endif

    if (!emmc_init()) {
        printf("FAILED TO INIT EMMC\n");
        return;
    }

    printf("EMMC Disk initialized\n");

    master_boot_record mbr;

    io_device *disk = io_device_find("disk");
    
    int r = disk->read(disk, &mbr, sizeof(mbr));

    printf("Read disk returned: %d\n", r);

    if (mbr.bootSignature != BOOT_SIGNATURE) {
        printf("BAD BOOT SIGNATURE: %X\n", mbr.bootSignature);
    }

    for (int i=0; i<4; i++) {
        if (mbr.partitions[i].type == 0) {
            break;
        }

        printf("Partition %d:\n", i);
        printf("\t Type: %d\n", mbr.partitions[i].type);
        printf("\t NumSecs: %d\n", mbr.partitions[i].num_sectors);
        printf("\t Status: %d\n", mbr.partitions[i].status);
        printf("\t Start: %X\n", mbr.partitions[i].first_lba_sector);
    }


	//int res = copy_process_inkernel((unsigned long)&kernel_func,0);
	//if (res != 0) {
	//	printf("error while starting process in kernel mode");
	//	//return;
	//}

      /* Call chain ①:
       * kernel_main -> copy_process(PF_KTHREAD, kernel_process, ...).
       * The new task first runs ret_from_fork, then kernel_process. */
      int  res = copy_process(PF_KTHREAD,(unsigned long)&kernel_process, 0,0);
	if (res<0) {
		printf("error while starting from kernel_process to user process");
		return;
	}

    res = copy_process(PF_KTHREAD, (unsigned long)&kernel_process2, 0, 0);
    if (res < 0) {
        printf("error while starting second user image\n");
        return;
    }

	while (1){
        printf("before schedule\r\n");
        printf("current task: %p\n", current);
		schedule();
	}	
        


    /*
    timer_sleep(15000);

    void *p1 = get_free_pages(10);
    void *p2 = get_free_pages(4);
    void *p3 = allocate_memory(20 * 4096 + 1);

    free_memory(p1);
    free_memory(p2);
    free_memory(p3);

    printf("\nException Level: %d\n", get_el());

    printf("Sleeping 200 ms...\n");
    timer_sleep(200);

    printf("Initializing I2C...\n");
    i2c_init();

    for (u8 i=0x20; i<0x30; i++) {
        if (i2c_send(i, &i, 1) == I2CS_SUCCESS) {
            //we know there is an i2c device here now.
            printf("Found device at address 0x%X\n", i);
        }
    }

    printf("Initializing SPI...\n");
    spi_init();

    printf("MAILBOX:\n");

    printf("CORE CLOCK: %d\n", mailbox_clock_rate(CT_CORE));
    printf("EMMC CLOCK: %d\n", mailbox_clock_rate(CT_EMMC));
    printf("UART CLOCK: %d\n", mailbox_clock_rate(CT_UART));
    printf("ARM  CLOCK: %d\n", mailbox_clock_rate(CT_ARM));

    printf("I2C POWER STATE:\n");

    for (int i=0; i<3; i++) {
        bool on = mailbox_power_check(i);

        printf("POWER DOMAIN STATUS FOR %d = %d\n", i, on);
    }

    //timer_sleep(2000);

    for (int i=0; i<3; i++) {
        u32 on = 1;
        mailbox_generic_command(RPI_FIRMWARE_SET_DOMAIN_STATE, i, &on);

        printf("SET POWER DOMAIN STATUS FOR %d = %d\n", i, on);
    }

    //timer_sleep(1000);

    for (int i=0; i<3; i++) {
        bool on = mailbox_power_check(i);

        printf("POWER DOMAIN STATUS FOR %d = %d\n", i, on);
    }

    u32 max_temp = 0;

    mailbox_generic_command(RPI_FIRMWARE_GET_MAX_TEMPERATURE, 0, &max_temp);

    //Do video...
    video_init();

    printf("NO DMA...\n");
    video_set_dma(false);

    printf("Resolution 1900x1200\n");
    video_set_resolution(1900, 1200, 32);

    printf("Resolution 1024x768\n");
    video_set_resolution(1024, 768, 32);

    printf("Resolution 800x600\n");
    video_set_resolution(800, 600, 32);

    printf("Resolution 1900x1200\n");
    video_set_resolution(1900, 1200, 8);

    printf("Resolution 1024x768\n");
    video_set_resolution(1024, 768, 8);

    printf("Resolution 800x600\n");
    video_set_resolution(800, 600, 8);

    printf("YES DMA...\n");
    video_set_dma(true);

    printf("Resolution 1900x1200\n");
    video_set_resolution(1900, 1200, 32);

    printf("Resolution 1024x768\n");
    video_set_resolution(1024, 768, 32);

    printf("Resolution 800x600\n");
    video_set_resolution(800, 600, 32);

    printf("Resolution 1900x1200\n");
    video_set_resolution(1900, 1200, 8);

    printf("Resolution 1024x768\n");
    video_set_resolution(1024, 768, 8);

    printf("Resolution 800x600\n");
    video_set_resolution(800, 600, 8);

    while(1) {
        u32 cur_temp = 0;

        mailbox_generic_command(RPI_FIRMWARE_GET_TEMPERATURE, 0, &cur_temp);

        printf("Cur temp: %dC MAX: %dC\n", cur_temp / 1000, max_temp / 1000);

        timer_sleep(1000);
    }
    */
}
