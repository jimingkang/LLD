#pragma once

//D1.10.2
#define SYNC_INVALID_EL1t		0 
#define IRQ_INVALID_EL1t		1 
#define FIQ_INVALID_EL1t		2 
#define ERROR_INVALID_EL1t		3 

#define SYNC_INVALID_EL1h		4 
#define IRQ_INVALID_EL1h		5 
#define FIQ_INVALID_EL1h		6 
#define ERROR_INVALID_EL1h		7 

#define SYNC_INVALID_EL0_64	    8 
#define IRQ_INVALID_EL0_64	    9 
#define FIQ_INVALID_EL0_64		10 
#define ERROR_INVALID_EL0_64	11 

#define SYNC_INVALID_EL0_32		12 
#define IRQ_INVALID_EL0_32		13 
#define FIQ_INVALID_EL0_32		14 
#define ERROR_INVALID_EL0_32	15 


#define SYNC_ERROR			16 
#define SYSCALL_ERROR			17 

//stack frame size
#define S_FRAME_SIZE			256+ 16

#define S_X0				0		// offset of x0 register in saved stack frame

#ifndef __ASSEMBLER__

void ret_from_fork(void);
void ret_to_user(void);
void ret_from_kernel_thread();

#endif
