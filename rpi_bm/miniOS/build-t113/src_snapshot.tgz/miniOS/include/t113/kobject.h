#ifndef MINIOS_T113_KOBJECT_H
#define MINIOS_T113_KOBJECT_H

#include <stdint.h>
#include "list.h"
#include "spinlock.h"

struct kobject;
struct kset;

struct kobj_type {
    void (*release)(struct kobject *kobj);
};

struct kref {
    uint32_t refs;
    spinlock_t lock;
};

struct kobject {
    const char *name;
    struct kobject *parent;
    struct kset *kset;
    const struct kobj_type *ktype;
    struct kref ref;
    struct list_head entry;
    uint32_t state_in_kset;
};

struct kset {
    struct kobject kobj;
    struct list_head members;
    spinlock_t lock;
};

void kobject_init(struct kobject *kobj, const struct kobj_type *ktype);
int kobject_add(struct kobject *kobj, struct kset *kset,
                struct kobject *parent, const char *name);
void kobject_del(struct kobject *kobj);
struct kobject *kobject_get(struct kobject *kobj);
void kobject_put(struct kobject *kobj);

void kset_init(struct kset *kset, const struct kobj_type *ktype);
int kset_register(struct kset *kset, struct kobject *parent,
                  const char *name);
void kset_unregister(struct kset *kset);
struct kobject *kset_find_obj(struct kset *kset, const char *name);

#endif
