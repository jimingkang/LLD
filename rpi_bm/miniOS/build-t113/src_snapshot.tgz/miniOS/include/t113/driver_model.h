#ifndef MINIOS_T113_DRIVER_MODEL_H
#define MINIOS_T113_DRIVER_MODEL_H

#include "kobject.h"

void t113_driver_core_init(void);
struct kset *t113_devices_kset(void);
struct kset *t113_drivers_kset(void);
struct kset *t113_buses_kset(void);

#endif
