#ifndef MINIOS_T113_DEVICE_H
#define MINIOS_T113_DEVICE_H

#include "kobject.h"

struct device;
struct device_driver;

struct bus_type {
    const char *name;
    struct kobject kobj;
    struct kset devices;
    struct kset drivers;
    int (*match)(struct device *dev, struct device_driver *drv);
};

struct device {
    const char *name;
    struct kobject kobj;
    struct bus_type *bus;
    struct device_driver *driver;
    void *driver_data;
};

struct device_driver {
    const char *name;
    struct kobject kobj;
    struct bus_type *bus;
    int (*probe)(struct device *dev);
    void (*remove)(struct device *dev);
};

int bus_register(struct bus_type *bus);
void bus_unregister(struct bus_type *bus);
int device_register(struct device *dev);
void device_unregister(struct device *dev);
int driver_register(struct device_driver *drv);
void driver_unregister(struct device_driver *drv);
void dev_set_drvdata(struct device *dev, void *data);
void *dev_get_drvdata(const struct device *dev);

#endif
