#ifndef MINIOS_LIMITS_H
#define MINIOS_LIMITS_H

#define CHAR_BIT   8
#define CHAR_MIN   (-128)
#define CHAR_MAX   127
#define UCHAR_MAX  255u
#define SHRT_MIN   (-32767 - 1)
#define SHRT_MAX   32767
#define USHRT_MAX  65535u
#define INT_MIN    (-2147483647 - 1)
#define INT_MAX    2147483647
#define UINT_MAX   4294967295u
#define LONG_MIN   INT_MIN
#define LONG_MAX   INT_MAX
#define ULONG_MAX  UINT_MAX

#endif
